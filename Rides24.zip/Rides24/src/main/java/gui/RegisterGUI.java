package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JInternalFrame;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class RegisterGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterGUI frame = new RegisterGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 372, 312);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(110, 79, 208, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JTextArea txtrEmail = new JTextArea();
		txtrEmail.setEditable(false);
		txtrEmail.setText("Email:");
		txtrEmail.setBounds(24, 77, 76, 22);
		contentPane.add(txtrEmail);
		
		JTextArea txtrName = new JTextArea();
		txtrName.setEditable(false);
		txtrName.setText("Name:");
		txtrName.setBounds(24, 11, 76, 22);
		contentPane.add(txtrName);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(110, 13, 105, 20);
		contentPane.add(textField_1);
		
		JTextArea txtrPassword = new JTextArea();
		txtrPassword.setEditable(false);
		txtrPassword.setText("Password:");
		txtrPassword.setBounds(24, 110, 76, 22);
		contentPane.add(txtrPassword);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(110, 110, 164, 20);
		contentPane.add(textField_2);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Driver");
		JRadioButton rdbtnNewRadioButton_1 = null;
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnNewRadioButton_1.setSelected(false);
			}
		});
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.setBackground(Color.WHITE);
		rdbtnNewRadioButton.setBounds(123, 144, 76, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		rdbtnNewRadioButton_1 = new JRadioButton("Traveler");
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnNewRadioButton.setSelected(false);
			}
		});
		rdbtnNewRadioButton_1.setBackground(Color.WHITE);
		rdbtnNewRadioButton_1.setBounds(209, 144, 86, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JTextArea txtrAlreadyHaveAn = new JTextArea();
		txtrAlreadyHaveAn.setEditable(false);
		txtrAlreadyHaveAn.setText("Already have an account?");
		txtrAlreadyHaveAn.setBounds(24, 235, 212, 22);
		contentPane.add(txtrAlreadyHaveAn);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(242, 235, 76, 24);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Register now!");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(87, 174, 208, 50);
		contentPane.add(btnNewButton_1);
		
		JTextArea txtrRename = new JTextArea();
		txtrRename.setText("Username:");
		txtrRename.setEditable(false);
		txtrRename.setBounds(24, 44, 76, 22);
		contentPane.add(txtrRename);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(110, 46, 105, 20);
		contentPane.add(textField_3);
		
		JTextArea txtrUserType = new JTextArea();
		txtrUserType.setText("User type:");
		txtrUserType.setEditable(false);
		txtrUserType.setBounds(24, 143, 86, 22);
		contentPane.add(txtrUserType);
	}
}
