package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Driver;

import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Color;

public class LoginRegisterGUI extends JFrame {

	private JPanel contentPane;
	private static BLFacade appFacadeInterface;
	private Driver driver;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginRegisterGUI frame = new LoginRegisterGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginRegisterGUI() {
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(335, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterGUI a=new RegisterGUI();
				a.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(235, 11, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Euskera");
		rdbtnNewRadioButton.setBackground(Color.WHITE);
		rdbtnNewRadioButton.setBounds(78, 231, 73, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnCastellano = new JRadioButton("Castellano");
		rdbtnCastellano.setBackground(Color.WHITE);
		rdbtnCastellano.setBounds(161, 231, 94, 23);
		contentPane.add(rdbtnCastellano);
		
		JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("English");
		rdbtnNewRadioButton_1_1.setBackground(Color.WHITE);
		rdbtnNewRadioButton_1_1.setBounds(257, 231, 73, 23);
		contentPane.add(rdbtnNewRadioButton_1_1);
		
		JTextArea txtrRides = new JTextArea();
		txtrRides.setEditable(false);
		txtrRides.setFont(new Font("Monospaced", Font.PLAIN, 54));
		txtrRides.setText("Rides24");
		txtrRides.setBounds(99, 68, 250, 87);
		contentPane.add(txtrRides);
		
		JTextPane txtpnBestRideComparator = new JTextPane();
		txtpnBestRideComparator.setEditable(false);
		txtpnBestRideComparator.setFont(new Font("Tahoma", Font.PLAIN, 17));
		txtpnBestRideComparator.setBackground(new Color(255, 255, 255));
		txtpnBestRideComparator.setText("Best ride comparator ever");
		txtpnBestRideComparator.setBounds(109, 149, 224, 20);
		contentPane.add(txtpnBestRideComparator);
	}
}
